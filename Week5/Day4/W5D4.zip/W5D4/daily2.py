import googletrans

french_words= ["Bonjour", "Au revoir", "Bienvenue", "A bientôt"] 

print(googletrans.LANGUAGES)

# {"Bonjour": "Hello", "Au revoir": "Goodbye", "Bienvenue": "Welcome", "A bientôt": "See you soon"}

