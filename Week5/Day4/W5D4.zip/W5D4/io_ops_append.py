file_location2 = 'files/file2.txt'

# 'a' - append
with open(file_location2, 'a') as file:
    file.write("\nThe sixth line")

