let sentence = "the movie is not that bad";

let arrWords = sentence.split(" ");

// arrWords
// (6) ['the', 'movie', 'is', 'not', 'that', 'bad']

let positionOfBad = arrWords.indexOf("bad");

// positionOfBad
// 5

arrWords.splice(positionOfBad, 1, "good") 

// arrWords
// (6) ['the', 'movie', 'is', 'not', 'that', 'good']

let newSentence = arrWords.join(" ")

// newSentence
// 'the movie is not that good'

//WITH STRING METHODS
// slice - extracting a part of the string
// substring
// replace - replace with something else

// WITH regular expression