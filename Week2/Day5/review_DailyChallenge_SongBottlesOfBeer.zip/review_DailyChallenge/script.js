function game() {
    let number = 45;
    let numberBottlesTakeDown = 0;

    // the loop runs 4 times
    for (let i = number; i > 0; i = i - numberBottlesTakeDown){
        numberBottlesTakeDown += 1;
        // number -= numberBottlesTakeDown;
        console.log(`The number of bottles remaining ${i}`);
        console.log(`The number of bottles taken down ${numberBottlesTakeDown}`);
    }

    // the while loop runs, while the condition is true
    // it stops when the difference is negative
    while(number - numberBottlesTakeDown >= 0){
        numberBottlesTakeDown += 1;
        number -= numberBottlesTakeDown;
        console.log(`The number of bottles remaining ${number}`);
        console.log(`The number of bottles taken down ${numberBottlesTakeDown}`);
    }
}

game()


