from django.contrib import admin
from django.urls import path
from films.views import (AddFilmView,
                        FilmListView,
                        add_director,
                        DirectorListView,
                        AddCategoryView,
                        DeleteCategoryView,
                        UpdateCategoryView)

from accounts.views import (IMDBLoginView, 
                            IMDBLogoutView,
                            RegisterView,
                            ProfileCreateView,
                            ProfileView)

urlpatterns = [
    path("admin/", admin.site.urls),
    path("add_film/", AddFilmView.as_view(), name='add_film'),
    path("films/", FilmListView.as_view(), name="films"),
    path("add_director/", add_director),
    path("directors/", DirectorListView.as_view(), name='directors'),
    path("add_category/", AddCategoryView.as_view()),
    path("delete_category/<int:pk>", DeleteCategoryView.as_view()),
    path("update_category/<int:pk>", UpdateCategoryView.as_view()),
    path("login/", IMDBLoginView.as_view(), name='login'),
    path("logout/", IMDBLogoutView.as_view(), name='logout'),
    path("register/", RegisterView.as_view()),
    path("profile_create/", ProfileCreateView.as_view(), name="profile_create"),
    path("profile/<int:pk>", ProfileView.as_view(), name='profile')
]
