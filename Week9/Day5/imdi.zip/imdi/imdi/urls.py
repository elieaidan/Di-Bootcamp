from django.contrib import admin
from django.urls import path
from films.views import AddFilmView, FilmListView, add_director, DirectorListView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("add_film/", AddFilmView.as_view()),
    path("films/", FilmListView.as_view(), name="films"),
    path("add_director/", add_director),
    path("directors/", DirectorListView.as_view(), name='directors')
]
