from django.shortcuts import render, redirect
from django.urls import reverse
from .models import Film, Director
from .forms import AddDirectorForm, AddFilmForm
from django.views.generic import FormView, ListView
# Create your views here.

class FilmListView(ListView):
    template_name = 'films.html'
    model = Film
    context_object_name = 'films'

class AddFilmView(FormView):
    template_name = 'add_film.html'
    form_class = AddFilmForm

    def get_success_url(self) -> str:
        return reverse('films')
    
    def form_valid(self, form): # runs when submit button clicked
        form.save()
        return super().form_valid(form)

def add_director(request):

    errors = {}

    if request.method == 'POST':
        form = AddDirectorForm(request.POST)
        if form.is_valid(): # checks that the data is ok
            form.save()
            return redirect('directors') # redirects to the directors page
        else:
            errors = form.errors

    form = AddDirectorForm()
    context = {'form': form, 'errors': errors}
    return render(request, 'add_director.html', context)



class DirectorListView(ListView):
    model = Director
    template_name = 'directors.html'
    context_object_name = 'directors'
